import json
import boto3
import os
from boto3.dynamodb.conditions import Key

dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table(os.environ.get("TABLE_NAME", "vigilwatch-endpoints"))

def api_handler(event, context):
    try:
        http_method = event.get("httpMethod")
        
        if http_method == "POST":
            body = json.loads(event.get("body", "{}"))
            table.put_item(Item=body)
            
            return {
                "statusCode": 201,
                "body": json.dumps({"message": "Endpoint registered"})
            }
        
        elif http_method == "GET":
            params = event.get("queryStringParameters") or {}
            endpoint = params.get("endpoint")
            
            if not endpoint:
                return {
                    "statusCode": 400,
                    "body": json.dumps({"error": "endpoint query parameter required"})
                }
            
            response = table.query(
                KeyConditionExpression=Key("endpoint").eq(endpoint)
            )
            
            return {
                "statusCode": 200,
                "body": json.dumps(response.get("Items", []))
            }
        
        else:
            return {
                "statusCode": 405,
                "body": json.dumps({"error": "Method not allowed"})
            }
    
    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }